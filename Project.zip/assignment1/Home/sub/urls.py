from django.urls import include, path
from . import views
from django.contrib import admin

urlpatterns = [
    path('', views.home, name='calculate'),
    path('subtract', views.subtract, name='subtract')

]